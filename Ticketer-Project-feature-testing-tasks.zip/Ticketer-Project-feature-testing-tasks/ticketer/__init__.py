"""Ticketer - A simple ticket booking system."""

__version__ = "0.0.1"
