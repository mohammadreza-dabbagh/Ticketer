"""Unit tests for price calculation logic."""

from decimal import Decimal

import pytest

from ticketer.services.order_service import calculate_price_with_fees


@pytest.mark.parametrize(
    "base_price,quantity,expected",
    [
        (Decimal("50.00"), 1, Decimal("55.00")),  # Single ticket: 50 + 10% fee = 55
        (Decimal("50.00"), 3, Decimal("165.00")),  # Multiple tickets: (50 * 3) + 10% fee = 165
        (
            Decimal("33.33"),
            3,
            Decimal("33.33") * Decimal("1.10") * Decimal("3"),
        ),  # Fractional: 33.33 * 3 + 10% fee
    ],
)
def test_calculate_price_with_fees(base_price, quantity, expected):
    """Test price calculation with various base prices and quantities."""
    total = calculate_price_with_fees(base_price, quantity)
    assert total == expected


def test_calculate_price_with_fees_zero_quantity():
    """Test price calculation when quantity is zero."""
    base_price = Decimal("50.00")
    quantity = 0

    total = calculate_price_with_fees(base_price, quantity)

    # 0 * 50 + 10% fee = 0
    assert total == Decimal("0.00")
