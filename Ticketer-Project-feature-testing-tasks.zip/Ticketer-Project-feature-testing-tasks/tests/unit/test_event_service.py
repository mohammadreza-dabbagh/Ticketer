"""Unit tests for EventService with mocked repository."""

from datetime import datetime, timedelta, timezone
from unittest.mock import Mock

import pytest

from ticketer.models.event import Event
from ticketer.repositories.event_repository import EventRepository
from ticketer.services.event_service import EventService


@pytest.fixture
def mock_event_repository():
    """Create a mock EventRepository."""
    return Mock(spec=EventRepository)


@pytest.fixture
def event_service(mock_event_repository):
    """Create EventService with mocked repository."""
    return EventService(event_repo=mock_event_repository)


def test_check_availability_event_not_found(event_service, mock_event_repository):
    """Test that check_availability raises ValueError when event is not found."""
    # Arrange
    event_id = 999
    requested_quantity = 2
    mock_event_repository.get_by_id.return_value = None

    # Act & Assert
    with pytest.raises(ValueError, match="Event not found"):
        event_service.check_availability(event_id, requested_quantity)

    # Verify mock was called
    mock_event_repository.get_by_id.assert_called_once_with(event_id)


def test_check_availability_sales_closed(event_service, mock_event_repository):
    """Test that check_availability returns False when sales are closed."""
    # Arrange
    event_id = 1
    requested_quantity = 2
    event = Event(
        id=event_id,
        venue_id=1,
        name="Test Event",
        start_at=datetime.now(timezone.utc) + timedelta(days=30),
        capacity=100,
        sales_open=False,  # Sales are closed
    )
    mock_event_repository.get_by_id.return_value = event

    # Act
    result = event_service.check_availability(event_id, requested_quantity)

    # Assert
    assert result is False
    mock_event_repository.get_by_id.assert_called_once_with(event_id)
    # get_reserved_count should not be called when sales are closed
    mock_event_repository.get_reserved_count.assert_not_called()


def test_check_availability_insufficient_capacity(event_service, mock_event_repository):
    """Test that check_availability returns False when there is insufficient capacity."""
    # Arrange
    event_id = 1
    requested_quantity = 50
    event = Event(
        id=event_id,
        venue_id=1,
        name="Test Event",
        start_at=datetime.now(timezone.utc) + timedelta(days=30),
        capacity=100,
        sales_open=True,
    )
    mock_event_repository.get_by_id.return_value = event
    mock_event_repository.get_reserved_count.return_value = 60  # 60 already reserved

    # Act
    result = event_service.check_availability(event_id, requested_quantity)

    # Assert
    assert result is False
    # Available capacity = 100 - 60 = 40, but requested = 50, so insufficient
    mock_event_repository.get_by_id.assert_called_once_with(event_id)
    mock_event_repository.get_reserved_count.assert_called_once_with(event_id)


def test_check_availability_sufficient_capacity(event_service, mock_event_repository):
    """Test that check_availability returns True when there is sufficient capacity."""
    # Arrange
    event_id = 1
    requested_quantity = 30
    event = Event(
        id=event_id,
        venue_id=1,
        name="Test Event",
        start_at=datetime.now(timezone.utc) + timedelta(days=30),
        capacity=100,
        sales_open=True,
    )
    mock_event_repository.get_by_id.return_value = event
    mock_event_repository.get_reserved_count.return_value = 50  # 50 already reserved

    # Act
    result = event_service.check_availability(event_id, requested_quantity)

    # Assert
    assert result is True
    # Available capacity = 100 - 50 = 50, requested = 30, so sufficient
    mock_event_repository.get_by_id.assert_called_once_with(event_id)
    mock_event_repository.get_reserved_count.assert_called_once_with(event_id)

