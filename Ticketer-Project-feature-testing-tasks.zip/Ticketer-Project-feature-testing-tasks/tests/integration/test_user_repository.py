"""Integration tests for user repository."""

import bcrypt
import hashlib
import pytest
from sqlalchemy.exc import IntegrityError

from ticketer.repositories.user_repository import SQLAlchemyUserRepository


def _hash_password(password: str) -> str:
    """Helper function to hash password like AuthService does."""
    pwd_hash = hashlib.sha256(password.encode()).hexdigest().encode()
    return bcrypt.hashpw(pwd_hash, bcrypt.gensalt()).decode()


def test_create_user_and_verify_saved(db_session):
    """Test creating a new user and verifying it is saved in the database."""
    # Arrange
    repo = SQLAlchemyUserRepository(db_session)
    email = "newuser@example.com"
    hashed_password = _hash_password("securepassword123")

    # Act
    user = repo.create(email=email, hashed_password=hashed_password)

    # Assert
    assert user.id is not None
    assert user.email == email
    assert user.hashed_password == hashed_password
    assert user.created_at is not None

    # Verify user is actually in the database
    retrieved_user = repo.get_by_id(user.id)
    assert retrieved_user is not None
    assert retrieved_user.email == email
    assert retrieved_user.id == user.id


def test_get_user_by_email(db_session):
    """Test retrieving a user from the database by email."""
    # Arrange
    repo = SQLAlchemyUserRepository(db_session)
    email = "testuser@example.com"
    hashed_password = _hash_password("testpassword")

    # Create user first
    created_user = repo.create(email=email, hashed_password=hashed_password)

    # Act
    retrieved_user = repo.get_by_email(email)

    # Assert
    assert retrieved_user is not None
    assert retrieved_user.id == created_user.id
    assert retrieved_user.email == email
    assert retrieved_user.hashed_password == hashed_password

    # Test with non-existent email
    non_existent = repo.get_by_email("nonexistent@example.com")
    assert non_existent is None


def test_prevent_duplicate_user_creation_constraint_error(db_session):
    """Test that creating a duplicate user raises ConstraintError."""
    # Arrange
    repo = SQLAlchemyUserRepository(db_session)
    email = "duplicate@example.com"
    hashed_password = _hash_password("password123")

    # Create first user
    first_user = repo.create(email=email, hashed_password=hashed_password)
    assert first_user.id is not None

    # Act & Assert - Try to create duplicate user
    with pytest.raises(IntegrityError) as exc_info:
        repo.create(email=email, hashed_password=hashed_password)

    # Verify it's a constraint violation (unique constraint on email)
    assert "unique" in str(exc_info.value).lower() or "duplicate" in str(exc_info.value).lower()

